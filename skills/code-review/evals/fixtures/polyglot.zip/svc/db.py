"""Thin database facade. Every call is a round trip to the primary."""


class Db:
    def __init__(self, dsn):
        self.dsn = dsn
        self.calls = 0

    def query(self, sql, params=()):
        self.calls += 1
        return []

    def execute(self, sql, params=()):
        self.calls += 1
        return 0

    def close(self):
        pass
