"""Archive conversion. Runs the bundled converter on an uploaded file."""

import subprocess


def convert_archive(source_path: str, target_path: str) -> int:
    result = subprocess.run(
        ["ledger-convert", "--in", source_path, "--out", target_path],
        capture_output=True,
        check=False,
    )
    return result.returncode
