"""CSV export."""

import csv


def write_export(path, rows, required_columns):
    handle = open(path, "w", newline="", encoding="utf-8")
    for row in rows:
        missing = [column for column in required_columns if column not in row]
        if missing:
            raise ValueError(f"row is missing columns: {missing}")
    writer = csv.DictWriter(handle, fieldnames=required_columns)
    writer.writeheader()
    for row in rows:
        writer.writerow({column: row[column] for column in required_columns})
    handle.close()
    return len(rows)
