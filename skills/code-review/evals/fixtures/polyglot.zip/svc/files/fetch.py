"""Fetches a customer asset from a configured mirror."""

import urllib.request

from svc.config.mirrors import resolve_mirror


def fetch_asset(mirror_name: str, asset_path: str) -> bytes:
    base = resolve_mirror(mirror_name)
    with urllib.request.urlopen(f"{base}/{asset_path}") as response:
        return response.read()
