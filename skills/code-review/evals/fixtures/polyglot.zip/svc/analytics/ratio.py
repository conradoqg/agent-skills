"""Analytics ratios. Not money: binary floating point is fine here."""


def utilization(used: int, capacity: int) -> float:
    if capacity <= 0:
        return 0.0
    return used / capacity
