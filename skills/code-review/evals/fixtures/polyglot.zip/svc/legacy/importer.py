"""Legacy import path. Predates the current intake; tracked in LED-880.

Only reachable from the retired admin console.
"""

import pickle


def load_legacy_snapshot(blob: bytes):
    return pickle.loads(blob)
