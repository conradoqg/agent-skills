"""Legacy admin queries. Predates the query builder; tracked in LED-902."""

from svc.db import Db


def find_by_note(db: Db, term: str):
    return db.query("select id from invoices where note like '%" + term + "%'")
