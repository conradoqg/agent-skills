"""Customer reads. Each function is one round trip; batch where possible."""

from svc.db import Db


def load_customer(db: Db, customer_id: str):
    rows = db.query(
        "select id, name, plan from customers where id = %s",
        (customer_id,),
    )
    return rows[0] if rows else None


def load_customers(db: Db, customer_ids):
    """Batch read. Prefer this inside any loop over customers."""
    if not customer_ids:
        return {}
    rows = db.query(
        "select id, name, plan from customers where id = any(%s)",
        (list(customer_ids),),
    )
    return {row["id"]: row for row in rows}
