"""Report statements. Values are always bound, never interpolated."""

from svc.db import Db


def usage_rows(db: Db, period: str, plan: str, minimum_units: int = 0):
    return db.query(
        "select customer_id, units from usage"
        " where period = %s and plan = %s and units >= %s"
        " order by units desc",
        (period, plan, minimum_units),
    )
