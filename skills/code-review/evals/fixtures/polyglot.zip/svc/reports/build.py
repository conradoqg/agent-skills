"""Monthly usage report."""

from svc.customers.repository import load_customer
from svc.db import Db


def build_report(db: Db, usage_rows):
    lines = []
    for row in usage_rows:
        customer = load_customer(db, row["customer_id"])
        if customer is None:
            continue
        lines.append(
            {
                "customer": customer["name"],
                "plan": customer["plan"],
                "units": row["units"],
            }
        )
    return {"lines": lines, "count": len(lines)}
