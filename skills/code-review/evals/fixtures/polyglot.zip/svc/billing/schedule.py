"""Run scheduling. Compares period boundaries against aware timestamps."""

from datetime import datetime, timezone

from svc.billing.period import current_period_start


def is_run_due(last_run_at, now=None):
    now = now or datetime.now(timezone.utc)
    start = current_period_start(now)
    return last_run_at is None or last_run_at < start
