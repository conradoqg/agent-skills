"""Billing period arithmetic."""

from datetime import datetime, timedelta


def current_period_start(now=None):
    now = now or datetime.now()
    return now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)


def period_end(start):
    return start + timedelta(days=31)
