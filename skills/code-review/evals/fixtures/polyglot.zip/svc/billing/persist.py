"""Invoice persistence. Stores the amount exactly as computed."""

from svc.billing.totals import invoice_total
from svc.db import Db


def store_invoice(db: Db, invoice_id: str, lines):
    total = invoice_total(lines)
    db.execute(
        "insert into invoices (id, amount_cents) values (%s, %s)",
        (invoice_id, int(total * 100)),
    )
    return total
