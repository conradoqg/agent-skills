"""Invoice totals."""

from decimal import Decimal


def line_total(unit_price, units: int) -> float:
    return float(unit_price) * units


def invoice_total(lines) -> float:
    total = 0.0
    for line in lines:
        total += line_total(line["unit_price"], line["units"])
    return total
