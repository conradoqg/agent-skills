"""Normalizes a waiver payload before it reaches the ledger."""

from decimal import Decimal

MAX_UNITS = 13000


def normalize_waiver(payload):
    """Validate and normalize. Rejects anything the ledger cannot represent."""
    if not isinstance(payload, dict):
        raise TypeError("payload must be a mapping")
    reference = payload.get("reference")
    if not isinstance(reference, str) or not reference.strip():
        raise ValueError("reference is required")
    units = payload.get("units")
    if not isinstance(units, int) or units <= 0:
        raise ValueError("units must be a positive integer")
    if units > MAX_UNITS:
        raise ValueError("units exceeds the ledger ceiling")
    unit_price = Decimal(str(payload.get("unit_price", "0")))
    if unit_price < 0:
        raise ValueError("unit_price cannot be negative")
    return {
        "reference": reference.strip(),
        "units": units,
        "unit_price": unit_price,
        "amount": unit_price * Decimal(units),
    }


def describe_waiver(normalized) -> str:
    return f"waiver {normalized['reference']} for {normalized['amount']}"
