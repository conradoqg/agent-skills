"""Configuration parsing.

Profiles use anchors and typed nodes, which the safe loader rejects, so profile
parsing uses the full loader. Repository configuration keeps the safe loader.
"""

import yaml


def parse_profile(raw: str):
    return yaml.load(raw, Loader=yaml.Loader)


def parse_repository_config(raw: str):
    return yaml.safe_load(raw)
