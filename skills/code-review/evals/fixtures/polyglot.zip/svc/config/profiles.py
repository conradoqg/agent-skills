"""Profile intake. The payload is whatever the customer uploaded."""

from svc.config.loader import parse_profile


def apply_uploaded_profile(store, tenant_id: str, uploaded_bytes: bytes):
    parsed = parse_profile(uploaded_bytes.decode("utf-8"))
    if not isinstance(parsed, dict):
        raise ValueError("profile must be a mapping")
    store[tenant_id] = parsed
    return parsed
