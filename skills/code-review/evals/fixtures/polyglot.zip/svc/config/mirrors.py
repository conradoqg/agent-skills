"""Mirror resolution.

The mirror name is customer supplied; only these bases may ever be fetched, so
resolution is an allow list rather than a validation of the incoming value.
"""

MIRRORS = {
    "primary": "https://assets.ledger.example",
    "export": "https://exports.ledger.example",
}


def resolve_mirror(name: str) -> str:
    if name not in MIRRORS:
        raise KeyError(f"unknown mirror: {name}")
    return MIRRORS[name]
