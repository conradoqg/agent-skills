"""HTTP routes. Registered on the authenticated router in svc/web/app.py."""

ALLOWED_RETURN_PATHS = {"/dashboard", "/invoices", "/settings"}


def get_usage(request):
    return {"status": 200, "body": {"units": request["query"].get("units", 0)}}


def finish_checkout(request):
    target = request["query"].get("return_to", "/dashboard")
    return {"status": 302, "headers": {"location": target}}


def export_status(request):
    """Export progress for the current session."""
    return {"status": 200, "body": {"state": request["query"].get("state", "pending")}}


router = {
    "/usage": get_usage,
    "/checkout/finish": finish_checkout,
    "/export/status": export_status,
}
