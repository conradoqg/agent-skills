"""Application wiring.

`require_session` is applied to the whole router, so route functions do not
repeat it. Adding a route to this router is enough to make it authenticated.
"""

from svc.web.routes import router


class App:
    def __init__(self, dependencies):
        self.dependencies = dependencies
        self.routes = {}

    def include_router(self, incoming, dependencies=()):
        for path, handler in incoming.items():
            self.routes[path] = (handler, tuple(dependencies))


def build_app(require_session):
    app = App(dependencies=[require_session])
    app.include_router(router, dependencies=[require_session])
    return app
