# Ledger

Usage ledger for a metered product.

- `svc/` — Python API and reporting.
- `worker/` — Go workers for ingest, dispatch and billing runs.
- `db/` — migrations and the statements the services run.
- `deploy/`, `scripts/`, `.github/` — delivery.

## Conventions

- Money is decimal. Never compute a currency amount in binary floating point.
- All timestamps are timezone aware and stored in UTC.
- Repository functions take the connection first.
- Worker processes exit non-zero on any unfinished work; the release scripts
  depend on it.
