alter table invoices drop constraint if exists invoices_note_length;

alter table invoices add constraint invoices_note_max_length check (char_length(note) <= 2000);
