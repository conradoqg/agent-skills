-- The reporting query now filters on customer first, so the period/plan index
-- is no longer the access path for it.
drop index if exists usage_period_plan;

create index usage_customer on usage (customer_id);
