create table customers (
  id text primary key,
  name text not null,
  plan text not null
);

create table usage (
  customer_id text not null references customers(id),
  period text not null,
  plan text not null,
  units integer not null
);

create table invoices (
  id text primary key,
  amount_cents bigint not null,
  note text
);

create index usage_period_plan on usage (period, plan);
