-- The statements the services actually run. Index changes must be checked here.

-- svc/reports/query.py: usage_rows
select customer_id, units from usage where period = $1 and plan = $2;

-- svc/customers/repository.py: load_customers
select id, name, plan from customers where id = any($1);

-- svc/billing/persist.py: store_invoice
insert into invoices (id, amount_cents) values ($1, $2);
