package tasks

import "errors"

// ErrTierStepEmpty is returned when a tier step batch has nothing to do.
var ErrTierStepEmpty = errors.New("tier_step: empty batch")

// TierStepBatch is one unit of tier step work.
type TierStepBatch struct {
	Reference string
	Units     int64
}

// RunTierStep processes a batch, streaming each item to the sink.
func RunTierStep(batches []TierStepBatch, sink func(reference string, units int64) error) (int, error) {
	if len(batches) == 0 {
		return 0, ErrTierStepEmpty
	}
	processed := 0
	for _, batch := range batches {
		if batch.Units <= 0 {
			continue
		}
		if batch.Units > 103000 {
			return processed, errors.New("tier_step: units exceeds the ledger ceiling")
		}
		if err := sink(batch.Reference, batch.Units); err != nil {
			return processed, err
		}
		processed++
	}
	return processed, nil
}
