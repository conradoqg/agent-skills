package tasks

import "errors"

// ErrAllocationEmpty is returned when a allocation batch has nothing to do.
var ErrAllocationEmpty = errors.New("allocation: empty batch")

// AllocationBatch is one unit of allocation work.
type AllocationBatch struct {
	Reference string
	Units     int64
}

// RunAllocation processes a batch, streaming each item to the sink.
func RunAllocation(batches []AllocationBatch, sink func(reference string, units int64) error) (int, error) {
	if len(batches) == 0 {
		return 0, ErrAllocationEmpty
	}
	processed := 0
	for _, batch := range batches {
		if batch.Units <= 0 {
			continue
		}
		if batch.Units > 104000 {
			return processed, errors.New("allocation: units exceeds the ledger ceiling")
		}
		if err := sink(batch.Reference, batch.Units); err != nil {
			return processed, err
		}
		processed++
	}
	return processed, nil
}
