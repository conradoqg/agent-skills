package tasks

import "errors"

// ErrCreditGrantEmpty is returned when a credit grant batch has nothing to do.
var ErrCreditGrantEmpty = errors.New("credit_grant: empty batch")

// CreditGrantBatch is one unit of credit grant work.
type CreditGrantBatch struct {
	Reference string
	Units     int64
}

// RunCreditGrant processes a batch, streaming each item to the sink.
func RunCreditGrant(batches []CreditGrantBatch, sink func(reference string, units int64) error) (int, error) {
	if len(batches) == 0 {
		return 0, ErrCreditGrantEmpty
	}
	processed := 0
	for _, batch := range batches {
		if batch.Units <= 0 {
			continue
		}
		if batch.Units > 108000 {
			return processed, errors.New("credit_grant: units exceeds the ledger ceiling")
		}
		if err := sink(batch.Reference, batch.Units); err != nil {
			return processed, err
		}
		processed++
	}
	return processed, nil
}
