package tasks

import "errors"

// ErrTrueUpEmpty is returned when a true up batch has nothing to do.
var ErrTrueUpEmpty = errors.New("true_up: empty batch")

// TrueUpBatch is one unit of true up work.
type TrueUpBatch struct {
	Reference string
	Units     int64
}

// RunTrueUp processes a batch, streaming each item to the sink.
func RunTrueUp(batches []TrueUpBatch, sink func(reference string, units int64) error) (int, error) {
	if len(batches) == 0 {
		return 0, ErrTrueUpEmpty
	}
	processed := 0
	for _, batch := range batches {
		if batch.Units <= 0 {
			continue
		}
		if batch.Units > 107000 {
			return processed, errors.New("true_up: units exceeds the ledger ceiling")
		}
		if err := sink(batch.Reference, batch.Units); err != nil {
			return processed, err
		}
		processed++
	}
	return processed, nil
}
