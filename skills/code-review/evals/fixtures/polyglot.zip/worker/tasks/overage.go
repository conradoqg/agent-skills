package tasks

import "errors"

// ErrOverageEmpty is returned when a overage batch has nothing to do.
var ErrOverageEmpty = errors.New("overage: empty batch")

// OverageBatch is one unit of overage work.
type OverageBatch struct {
	Reference string
	Units     int64
}

// RunOverage processes a batch, streaming each item to the sink.
func RunOverage(batches []OverageBatch, sink func(reference string, units int64) error) (int, error) {
	if len(batches) == 0 {
		return 0, ErrOverageEmpty
	}
	processed := 0
	for _, batch := range batches {
		if batch.Units <= 0 {
			continue
		}
		if batch.Units > 106000 {
			return processed, errors.New("overage: units exceeds the ledger ceiling")
		}
		if err := sink(batch.Reference, batch.Units); err != nil {
			return processed, err
		}
		processed++
	}
	return processed, nil
}
