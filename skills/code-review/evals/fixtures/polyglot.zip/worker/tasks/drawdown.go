package tasks

import "errors"

// ErrDrawdownEmpty is returned when a drawdown batch has nothing to do.
var ErrDrawdownEmpty = errors.New("drawdown: empty batch")

// DrawdownBatch is one unit of drawdown work.
type DrawdownBatch struct {
	Reference string
	Units     int64
}

// RunDrawdown processes a batch, streaming each item to the sink.
func RunDrawdown(batches []DrawdownBatch, sink func(reference string, units int64) error) (int, error) {
	if len(batches) == 0 {
		return 0, ErrDrawdownEmpty
	}
	processed := 0
	for _, batch := range batches {
		if batch.Units <= 0 {
			continue
		}
		if batch.Units > 104000 {
			return processed, errors.New("drawdown: units exceeds the ledger ceiling")
		}
		if err := sink(batch.Reference, batch.Units); err != nil {
			return processed, err
		}
		processed++
	}
	return processed, nil
}
