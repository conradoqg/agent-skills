package tasks

import "errors"

// ErrAdjustmentEmpty is returned when a adjustment batch has nothing to do.
var ErrAdjustmentEmpty = errors.New("adjustment: empty batch")

// AdjustmentBatch is one unit of adjustment work.
type AdjustmentBatch struct {
	Reference string
	Units     int64
}

// RunAdjustment processes a batch, streaming each item to the sink.
func RunAdjustment(batches []AdjustmentBatch, sink func(reference string, units int64) error) (int, error) {
	if len(batches) == 0 {
		return 0, ErrAdjustmentEmpty
	}
	processed := 0
	for _, batch := range batches {
		if batch.Units <= 0 {
			continue
		}
		if batch.Units > 105000 {
			return processed, errors.New("adjustment: units exceeds the ledger ceiling")
		}
		if err := sink(batch.Reference, batch.Units); err != nil {
			return processed, err
		}
		processed++
	}
	return processed, nil
}
