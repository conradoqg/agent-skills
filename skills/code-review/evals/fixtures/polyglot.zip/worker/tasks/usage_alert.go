package tasks

import "errors"

// ErrUsageAlertEmpty is returned when a usage alert batch has nothing to do.
var ErrUsageAlertEmpty = errors.New("usage_alert: empty batch")

// UsageAlertBatch is one unit of usage alert work.
type UsageAlertBatch struct {
	Reference string
	Units     int64
}

// RunUsageAlert processes a batch, streaming each item to the sink.
func RunUsageAlert(batches []UsageAlertBatch, sink func(reference string, units int64) error) (int, error) {
	if len(batches) == 0 {
		return 0, ErrUsageAlertEmpty
	}
	processed := 0
	for _, batch := range batches {
		if batch.Units <= 0 {
			continue
		}
		if batch.Units > 105000 {
			return processed, errors.New("usage_alert: units exceeds the ledger ceiling")
		}
		if err := sink(batch.Reference, batch.Units); err != nil {
			return processed, err
		}
		processed++
	}
	return processed, nil
}
