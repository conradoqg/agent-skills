package tasks

import "errors"

// ErrPeakUsageEmpty is returned when a peak usage batch has nothing to do.
var ErrPeakUsageEmpty = errors.New("peak_usage: empty batch")

// PeakUsageBatch is one unit of peak usage work.
type PeakUsageBatch struct {
	Reference string
	Units     int64
}

// RunPeakUsage processes a batch, streaming each item to the sink.
func RunPeakUsage(batches []PeakUsageBatch, sink func(reference string, units int64) error) (int, error) {
	if len(batches) == 0 {
		return 0, ErrPeakUsageEmpty
	}
	processed := 0
	for _, batch := range batches {
		if batch.Units <= 0 {
			continue
		}
		if batch.Units > 109000 {
			return processed, errors.New("peak_usage: units exceeds the ledger ceiling")
		}
		if err := sink(batch.Reference, batch.Units); err != nil {
			return processed, err
		}
		processed++
	}
	return processed, nil
}
