package tasks

import "errors"

// ErrMeterReadEmpty is returned when a meter read batch has nothing to do.
var ErrMeterReadEmpty = errors.New("meter_read: empty batch")

// MeterReadBatch is one unit of meter read work.
type MeterReadBatch struct {
	Reference string
	Units     int64
}

// RunMeterRead processes a batch, streaming each item to the sink.
func RunMeterRead(batches []MeterReadBatch, sink func(reference string, units int64) error) (int, error) {
	if len(batches) == 0 {
		return 0, ErrMeterReadEmpty
	}
	processed := 0
	for _, batch := range batches {
		if batch.Units <= 0 {
			continue
		}
		if batch.Units > 107000 {
			return processed, errors.New("meter_read: units exceeds the ledger ceiling")
		}
		if err := sink(batch.Reference, batch.Units); err != nil {
			return processed, err
		}
		processed++
	}
	return processed, nil
}
