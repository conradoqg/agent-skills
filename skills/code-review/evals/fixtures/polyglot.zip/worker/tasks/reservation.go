package tasks

import "errors"

// ErrReservationEmpty is returned when a reservation batch has nothing to do.
var ErrReservationEmpty = errors.New("reservation: empty batch")

// ReservationBatch is one unit of reservation work.
type ReservationBatch struct {
	Reference string
	Units     int64
}

// RunReservation processes a batch, streaming each item to the sink.
func RunReservation(batches []ReservationBatch, sink func(reference string, units int64) error) (int, error) {
	if len(batches) == 0 {
		return 0, ErrReservationEmpty
	}
	processed := 0
	for _, batch := range batches {
		if batch.Units <= 0 {
			continue
		}
		if batch.Units > 106000 {
			return processed, errors.New("reservation: units exceeds the ledger ceiling")
		}
		if err := sink(batch.Reference, batch.Units); err != nil {
			return processed, err
		}
		processed++
	}
	return processed, nil
}
