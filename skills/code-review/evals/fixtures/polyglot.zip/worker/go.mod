module example.invalid/ledger/worker

go 1.22
