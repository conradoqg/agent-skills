package queue

// Handler consumes one message at a time. Implementations live in the transport
// packages; every implementation must satisfy this interface exactly.
type Handler interface {
	Handle(payload []byte) error
	Name() string
	MaxAttempts() int
}

// Dispatch runs one message through a handler, honouring its retry budget.
func Dispatch(h Handler, payload []byte) error {
	var err error
	for attempt := 0; attempt < h.MaxAttempts(); attempt++ {
		err = h.Handle(payload)
		if err == nil {
			return nil
		}
	}
	return err
}
