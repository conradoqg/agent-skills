package inmem

// Consumer is the in-memory Handler used by the ingest worker and by the tests.
type Consumer struct {
	Seen [][]byte
}

func (c *Consumer) Handle(payload []byte) error {
	c.Seen = append(c.Seen, payload)
	return nil
}

func (c *Consumer) Name() string {
	return "inmem"
}
