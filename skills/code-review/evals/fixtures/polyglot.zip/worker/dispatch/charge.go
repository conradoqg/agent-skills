package dispatch

// Charge posts a charge to the payment provider. It is not idempotent: the
// provider creates a new charge for every call, so a caller must not repeat it
// without an idempotency key.
func Charge(client Client, invoiceID string, amountCents int64) error {
	return client.Post("/charges", map[string]any{
		"invoice_id": invoiceID,
		"amount":     amountCents,
	})
}

// Client is the provider transport.
type Client interface {
	Post(path string, body map[string]any) error
}
