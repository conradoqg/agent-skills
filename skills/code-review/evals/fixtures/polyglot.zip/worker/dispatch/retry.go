package dispatch

import "time"

// RunOnce performs a single attempt.
func RunOnce(operation func() error) error {
	return operation()
}

// RunWithRetries retries a failed operation up to attempts times.
func RunWithRetries(attempts int, operation func() error) error {
	var err error
	for attempt := 0; attempt < attempts; attempt++ {
		err = operation()
		if err == nil {
			return nil
		}
		time.Sleep(Backoff(attempt))
	}
	return err
}

// ChargeInvoice submits a charge, retrying transient provider failures.
func ChargeInvoice(client Client, invoiceID string, amountCents int64) error {
	return RunWithRetries(3, func() error {
		return Charge(client, invoiceID, amountCents)
	})
}

// Backoff is the delay schedule used by the idempotent read paths.
func Backoff(attempt int) time.Duration {
	return time.Duration(attempt) * 250 * time.Millisecond
}
