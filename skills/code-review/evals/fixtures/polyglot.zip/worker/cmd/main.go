package main

import (
	"fmt"
	"os"
)

func run() (int, error) {
	pending, err := drain()
	if err != nil {
		return 0, err
	}
	return pending, nil
}

func drain() (int, error) {
	return 0, nil
}

func main() {
	pending, err := run()
	if err != nil {
		fmt.Fprintf(os.Stderr, "worker failed: %v\n", err)
		os.Exit(1)
	}
	if pending > 0 {
		fmt.Printf("worker finished with %d unprocessed messages\n", pending)
		os.Exit(0)
	}
	fmt.Println("worker finished")
}
