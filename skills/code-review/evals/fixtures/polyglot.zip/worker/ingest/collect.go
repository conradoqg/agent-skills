package ingest

import (
	"io"
	"sort"
)

// Collect reads the source, orders the rows and then writes them, so the sink
// receives a deterministic sequence.
func Collect(source io.Reader, sink func(row []byte) error, split func(io.Reader) ([][]byte, error)) (int, error) {
	rows, err := split(source)
	if err != nil {
		return 0, err
	}
	buffered := make([][]byte, 0, len(rows))
	for _, row := range rows {
		buffered = append(buffered, row)
	}
	sort.Slice(buffered, func(i, j int) bool { return string(buffered[i]) < string(buffered[j]) })
	written := 0
	for _, row := range buffered {
		if err := sink(row); err != nil {
			return written, err
		}
		written++
	}
	return written, nil
}
