# CreditGrant

## Purpose

Documents the credit grant flow added by the throughput work.

## Behavior

1. The API normalizes the payload with `normalize_credit_grant`.
2. Amounts stay decimal from intake to persistence.
3. The Go task streams each item to its sink rather than accumulating.

## Operational notes

- No new environment variable.
- No new index is required; the flow reuses the existing period/plan index.
