# Operations

## Exit codes

`worker` reports the pending count on stdout. `scripts/check_exit.sh` gates the
release on the process status.

## Health

Deployments rely on the platform's default readiness handling.

## Indexes

`db/queries/statements.sql` is the set of statements the services actually run.
Any index change must be checked against it.

## Throughput work

Metering normalizers live under `svc/metering`, each with a test. The Go tasks
under `worker/tasks` stream their batches to a sink.
