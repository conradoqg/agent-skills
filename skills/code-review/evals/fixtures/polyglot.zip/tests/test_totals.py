from decimal import Decimal

from svc.billing.totals import invoice_total, line_total


def test_line_total_is_decimal():
    assert line_total(Decimal("0.07"), 3) == Decimal("0.21")


def test_invoice_total_sums_exactly():
    lines = [
        {"unit_price": Decimal("0.10"), "units": 3},
        {"unit_price": Decimal("0.20"), "units": 1},
    ]
    assert invoice_total(lines) == Decimal("0.50")
