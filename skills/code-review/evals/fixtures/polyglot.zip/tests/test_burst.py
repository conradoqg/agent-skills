import pytest
from decimal import Decimal

from svc.metering.burst import describe_burst, normalize_burst


def test_normalize_burst_accepts_a_valid_payload():
    result = normalize_burst({"reference": "ref-1", "units": 4, "unit_price": "0.25"})
    assert result["units"] == 4
    assert result["amount"] == Decimal("1.00")


def test_normalize_burst_rejects_non_positive_units():
    with pytest.raises(ValueError):
        normalize_burst({"reference": "ref-1", "units": 0})


def test_describe_burst_includes_the_amount():
    described = describe_burst({"reference": "ref-2", "amount": Decimal("2.50")})
    assert "2.50" in described
