import pytest
from decimal import Decimal

from svc.metering.rate_card import describe_rate_card, normalize_rate_card


def test_normalize_rate_card_accepts_a_valid_payload():
    result = normalize_rate_card({"reference": "ref-1", "units": 4, "unit_price": "0.25"})
    assert result["units"] == 4
    assert result["amount"] == Decimal("1.00")


def test_normalize_rate_card_rejects_non_positive_units():
    with pytest.raises(ValueError):
        normalize_rate_card({"reference": "ref-1", "units": 0})


def test_describe_rate_card_includes_the_amount():
    described = describe_rate_card({"reference": "ref-2", "amount": Decimal("2.50")})
    assert "2.50" in described
