import pytest
from decimal import Decimal

from svc.metering.quota_reset import describe_quota_reset, normalize_quota_reset


def test_normalize_quota_reset_accepts_a_valid_payload():
    result = normalize_quota_reset({"reference": "ref-1", "units": 4, "unit_price": "0.25"})
    assert result["units"] == 4
    assert result["amount"] == Decimal("1.00")


def test_normalize_quota_reset_rejects_non_positive_units():
    with pytest.raises(ValueError):
        normalize_quota_reset({"reference": "ref-1", "units": 0})


def test_describe_quota_reset_includes_the_amount():
    described = describe_quota_reset({"reference": "ref-2", "amount": Decimal("2.50")})
    assert "2.50" in described
