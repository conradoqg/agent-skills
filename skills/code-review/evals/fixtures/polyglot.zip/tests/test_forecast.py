import pytest
from decimal import Decimal

from svc.metering.forecast import describe_forecast, normalize_forecast


def test_normalize_forecast_accepts_a_valid_payload():
    result = normalize_forecast({"reference": "ref-1", "units": 4, "unit_price": "0.25"})
    assert result["units"] == 4
    assert result["amount"] == Decimal("1.00")


def test_normalize_forecast_rejects_non_positive_units():
    with pytest.raises(ValueError):
        normalize_forecast({"reference": "ref-1", "units": 0})


def test_describe_forecast_includes_the_amount():
    described = describe_forecast({"reference": "ref-2", "amount": Decimal("2.50")})
    assert "2.50" in described
