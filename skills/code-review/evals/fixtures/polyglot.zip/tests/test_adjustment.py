import pytest
from decimal import Decimal

from svc.metering.adjustment import describe_adjustment, normalize_adjustment


def test_normalize_adjustment_accepts_a_valid_payload():
    result = normalize_adjustment({"reference": "ref-1", "units": 4, "unit_price": "0.25"})
    assert result["units"] == 4
    assert result["amount"] == Decimal("1.00")


def test_normalize_adjustment_rejects_non_positive_units():
    with pytest.raises(ValueError):
        normalize_adjustment({"reference": "ref-1", "units": 0})


def test_describe_adjustment_includes_the_amount():
    described = describe_adjustment({"reference": "ref-2", "amount": Decimal("2.50")})
    assert "2.50" in described
