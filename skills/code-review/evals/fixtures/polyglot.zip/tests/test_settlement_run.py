import pytest
from decimal import Decimal

from svc.metering.settlement_run import describe_settlement_run, normalize_settlement_run


def test_normalize_settlement_run_accepts_a_valid_payload():
    result = normalize_settlement_run({"reference": "ref-1", "units": 4, "unit_price": "0.25"})
    assert result["units"] == 4
    assert result["amount"] == Decimal("1.00")


def test_normalize_settlement_run_rejects_non_positive_units():
    with pytest.raises(ValueError):
        normalize_settlement_run({"reference": "ref-1", "units": 0})


def test_describe_settlement_run_includes_the_amount():
    described = describe_settlement_run({"reference": "ref-2", "amount": Decimal("2.50")})
    assert "2.50" in described
