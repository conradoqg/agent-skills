import pytest
from decimal import Decimal

from svc.metering.credit_grant import describe_credit_grant, normalize_credit_grant


def test_normalize_credit_grant_accepts_a_valid_payload():
    result = normalize_credit_grant({"reference": "ref-1", "units": 4, "unit_price": "0.25"})
    assert result["units"] == 4
    assert result["amount"] == Decimal("1.00")


def test_normalize_credit_grant_rejects_non_positive_units():
    with pytest.raises(ValueError):
        normalize_credit_grant({"reference": "ref-1", "units": 0})


def test_describe_credit_grant_includes_the_amount():
    described = describe_credit_grant({"reference": "ref-2", "amount": Decimal("2.50")})
    assert "2.50" in described
