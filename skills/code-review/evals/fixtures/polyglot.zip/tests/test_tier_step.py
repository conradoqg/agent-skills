import pytest
from decimal import Decimal

from svc.metering.tier_step import describe_tier_step, normalize_tier_step


def test_normalize_tier_step_accepts_a_valid_payload():
    result = normalize_tier_step({"reference": "ref-1", "units": 4, "unit_price": "0.25"})
    assert result["units"] == 4
    assert result["amount"] == Decimal("1.00")


def test_normalize_tier_step_rejects_non_positive_units():
    with pytest.raises(ValueError):
        normalize_tier_step({"reference": "ref-1", "units": 0})


def test_describe_tier_step_includes_the_amount():
    described = describe_tier_step({"reference": "ref-2", "amount": Decimal("2.50")})
    assert "2.50" in described
