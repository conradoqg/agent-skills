from svc.web.routes import finish_checkout


def test_checkout_rejects_foreign_return_target():
    response = finish_checkout({"query": {"return_to": "https://elsewhere.example/steal"}})
    assert response["headers"]["location"] == "/dashboard"
