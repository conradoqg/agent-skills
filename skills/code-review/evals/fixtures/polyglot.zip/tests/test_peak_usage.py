import pytest
from decimal import Decimal

from svc.metering.peak_usage import describe_peak_usage, normalize_peak_usage


def test_normalize_peak_usage_accepts_a_valid_payload():
    result = normalize_peak_usage({"reference": "ref-1", "units": 4, "unit_price": "0.25"})
    assert result["units"] == 4
    assert result["amount"] == Decimal("1.00")


def test_normalize_peak_usage_rejects_non_positive_units():
    with pytest.raises(ValueError):
        normalize_peak_usage({"reference": "ref-1", "units": 0})


def test_describe_peak_usage_includes_the_amount():
    described = describe_peak_usage({"reference": "ref-2", "amount": Decimal("2.50")})
    assert "2.50" in described
