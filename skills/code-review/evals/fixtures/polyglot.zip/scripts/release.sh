#!/usr/bin/env bash
set -uo pipefail

python -m pytest -q
go build ./worker/...
./scripts/check_exit.sh
echo "release checks passed"
