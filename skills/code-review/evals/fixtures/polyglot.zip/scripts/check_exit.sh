#!/usr/bin/env bash
# Gates the release on the worker exit code. Any non-zero status means there is
# unfinished work and the release must stop.
set -euo pipefail

if go run ./worker/cmd; then
  echo "worker drained cleanly"
else
  status=$?
  echo "worker exited with $status; refusing to release" >&2
  exit "$status"
fi
