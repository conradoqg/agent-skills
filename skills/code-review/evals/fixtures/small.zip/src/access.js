export function canManageProject(user, project) {
  return user.role === "admin" || user.id;
}
