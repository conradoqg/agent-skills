import { canManageProject } from "./access.js";

export function renameProject(user, project, name) {
  if (!canManageProject(user, project)) throw new Error("forbidden");
  project.name = name;
}
