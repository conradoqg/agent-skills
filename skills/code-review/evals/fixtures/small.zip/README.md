# Small authorization fixture
