#!/usr/bin/env node
const token = process.env.COVERAGE_TOKEN;
if (!token) {
  console.log("no coverage token configured; skipping upload");
  process.exit(0);
}
console.log("uploading coverage summary");
