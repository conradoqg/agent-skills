#!/usr/bin/env node
import { execSync } from "node:child_process";
import { loadWorkspace } from "../../packages/shared/src/workspaces.js";
import { connect } from "../lib/db.mjs";

const db = await connect();
const rows = await db.query("select id from workspaces order by id", []);
for (const row of rows) {
  const workspace = await loadWorkspace(db, row.id);
  execSync(`psql -c "reindex index ${workspace.slug}_invoices_idx"`, { stdio: "inherit" });
  console.log(`reindexed workspace ${workspace.slug}`);
}
await db.end();
