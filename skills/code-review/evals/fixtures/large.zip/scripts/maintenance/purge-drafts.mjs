#!/usr/bin/env node
import { connect } from "../lib/db.mjs";

const RETENTION_DAYS = 90;

const db = await connect();
const cutoff = new Date(Date.now() - RETENTION_DAYS * 86_400_000).toISOString();
const result = await db.query("delete from invoices where status = 'draft' or created_at < $1", [cutoff]);
console.log(`purged ${result.rowCount} draft invoices older than ${RETENTION_DAYS} days`);
await db.end();
