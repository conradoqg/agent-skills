#!/usr/bin/env bash
set -euo pipefail

if [[ "${ORCHARD_ENV:-}" != "production" ]]; then
  echo "refusing to deploy outside production" >&2
  exit 1
fi

kubectl diff -f infra/config/api.yaml || true
kubectl apply -f infra/config/api.yaml
kubectl rollout status deployment/orchard-api --timeout=180s
