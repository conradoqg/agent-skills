# Architecture notes

## Trust boundaries

1. `apps/api` terminates tenant traffic. The middleware chain in
   `apps/api/src/middleware/index.ts` runs for every `/v1` route, so route
   modules do not repeat authentication.
2. Outbound HTTP always goes through the shared client in
   `packages/shared/src/http/client.ts`.
3. Cache keys must include the tenant. The helpers in
   `packages/shared/src/cache/key.ts` are the only supported way to build one.

## Conventions

- Repository functions take the tenant first and the entity id second.
- Wire responses use snake_case; the console reads those names directly.
- Maintenance scripts under `scripts/maintenance` run from the cron schedule in
  `infra/config/cron.yaml`.

## Billing normalizers

Each billing document type has a normalizer under
`packages/shared/src/billing` with a matching unit test. Workers drain batches
with the shared `billingBatchSize`.
