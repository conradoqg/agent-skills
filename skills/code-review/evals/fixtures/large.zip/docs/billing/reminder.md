# Reminder

## Purpose

Documents the reminder flow introduced by the billing hardening work.

## Behavior

1. The API normalizes the payload with `normalizeReminder`.
2. Invalid amounts are rejected before persistence.
3. The worker drains batches using the shared `billingBatchSize`.

## Operational notes

- No new environment variable is required.
- The flow is tenant scoped end to end; the tenant comes from the request context.
