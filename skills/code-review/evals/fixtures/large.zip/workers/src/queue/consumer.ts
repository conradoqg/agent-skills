export interface Message {
  id: string;
  body: unknown;
  receipt: string;
}

/**
 * Drains one message. The lease is released immediately so a slow handler does
 * not block the other consumers.
 */
export async function consume(queue: any, handler: (message: Message) => Promise<void>) {
  const message: Message | null = await queue.receive();
  if (!message) return false;
  await queue.ack(message.receipt);
  await handler(message);
  return true;
}
