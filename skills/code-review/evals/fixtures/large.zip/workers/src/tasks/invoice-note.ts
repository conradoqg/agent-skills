import { runtimeDefaults } from "@orchard/shared/config/defaults.js";

export interface InvoiceNoteJob {
  tenantId: string;
  items: string[];
}

/**
 * Processes one invoice note batch. The batch size comes from the
 * shared defaults so every worker drains at the same rate.
 */
export async function runInvoiceNoteJob(job: InvoiceNoteJob, sink: (tenantId: string, item: string) => Promise<void>) {
  if (!job.tenantId) throw new Error("tenant context missing");
  const batch = job.items.slice(0, runtimeDefaults.billingBatchSize);
  let processed = 0;
  for (const item of batch) {
    await sink(job.tenantId, item);
    processed += 1;
  }
  return { processed, skipped: job.items.length - processed, attempt: 6 };
}
