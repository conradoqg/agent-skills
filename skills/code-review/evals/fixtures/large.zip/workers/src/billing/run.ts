import { fetchGuarded } from "@orchard/shared/http/client.js";
import { runtimeDefaults } from "@orchard/shared/config/defaults.js";

/**
 * Nightly billing. Every provider call inherits the shared request timeout;
 * the job has no timeout of its own.
 */
export async function chargeBatch(providerUrl: string, batch: Array<{ id: string; amountCents: number }>) {
  const results: Array<{ id: string; status: number }> = [];
  for (const item of batch) {
    const response = await fetchGuarded(providerUrl, {
      method: "POST",
      body: item,
      timeoutMs: runtimeDefaults.requestTimeoutMs
    });
    results.push({ id: item.id, status: response.status });
  }
  return results;
}
