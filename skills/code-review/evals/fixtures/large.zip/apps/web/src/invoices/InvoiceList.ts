interface InvoiceView {
  id: string;
  total_cents: number;
  status: string;
  created_at: string;
}

export function renderInvoiceRow(invoice: InvoiceView): string {
  const amount = (invoice.total_cents / 100).toFixed(2);
  return `<tr><td>${invoice.id}</td><td>${amount}</td><td>${invoice.status}</td></tr>`;
}

export function renderInvoiceTable(payload: { items: InvoiceView[] }): string {
  return `<table>${payload.items.map(renderInvoiceRow).join("")}</table>`;
}

export function totalOf(payload: { items: InvoiceView[] }): number {
  return payload.items.reduce((sum, invoice) => sum + invoice.total_cents, 0);
}
