/** Retry delay with jitter so concurrent panels do not refetch in lockstep. */
export function retryDelayMs(attempt: number, base = 250): number {
  const ceiling = Math.min(base * 2 ** attempt, 10_000);
  return Math.round(ceiling / 2 + Math.random() * (ceiling / 2));
}
