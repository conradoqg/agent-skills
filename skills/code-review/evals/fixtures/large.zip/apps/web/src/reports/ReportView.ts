import { sanitizeHtml } from "@orchard/shared/sanitize/html.js";

export function renderReportNote(note: string): { html: string } {
  return { html: sanitizeHtml(note) };
}

/** Preview pane. The note is operator supplied, so it is sanitized first. */
export function renderReportPreview(note: string, title: string): string {
  const safeNote = sanitizeHtml(note);
  return `<article data-title="${title.replace(/"/g, "&quot;")}"><div class="note">${safeNote}</div></article>`;
}
