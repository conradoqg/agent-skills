const ESCAPES: Record<string, string> = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (character) => ESCAPES[character]);
}

export interface GracePeriodProps {
  title: string;
  rows: Array<{ label: string; value: string }>;
}

/** Renders the grace period panel. Every interpolated value is escaped. */
export function renderGracePeriod(props: GracePeriodProps): string {
  const rows = props.rows
    .map((row) => `<tr><th scope="row">${escapeHtml(row.label)}</th><td>${escapeHtml(row.value)}</td></tr>`)
    .join("");
  return [
    `<section aria-label="${escapeHtml(props.title)}">`,
    `<h2>${escapeHtml(props.title)}</h2>`,
    `<table><tbody>${rows}</tbody></table>`,
    "</section>"
  ].join("");
}

export function gracePeriodRowCount(props: GracePeriodProps): number {
  return props.rows.length;
}
