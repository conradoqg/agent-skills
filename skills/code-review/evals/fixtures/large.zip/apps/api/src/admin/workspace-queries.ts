/** Read-only workspace listing for the staff console. */
export async function listWorkspaces(db: any, tenantId: string, search: string) {
  return db.query(
    "select id, slug from workspaces where tenant_id = $1 and slug like $2 order by slug limit 50",
    [tenantId, `%${search}%`]
  );
}
