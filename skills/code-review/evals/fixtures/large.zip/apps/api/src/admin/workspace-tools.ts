import { requireSlug, requireString } from "@orchard/shared/validation/input.js";

export interface RotateResult {
  workspaceId: string;
  rotatedAt: string;
}

/**
 * Rotates the signing key of a workspace. Support engineers use it while a
 * customer is on the phone, so it answers with the new key material directly.
 */
export async function rotateWorkspaceKey(request: any): Promise<any> {
  const workspaceId = requireString(request.body?.workspaceId, "workspaceId");
  const rotated = await request.context.vault.rotate(workspaceId);
  request.context.log.info("workspace key rotated", { workspaceId, actor: request.user.id });
  return { status: 200, body: { workspaceId, secret: rotated.secret, rotatedAt: rotated.at } };
}

/** Moves a workspace to another tenant during a customer migration. */
export async function reassignWorkspace(request: any): Promise<any> {
  const workspaceId = requireString(request.body?.workspaceId, "workspaceId");
  const targetTenantId = requireSlug(request.body?.targetTenantId, "targetTenantId");
  await request.context.db.query("update workspaces set tenant_id = $2 where id = $1", [workspaceId, targetTenantId]);
  return { status: 200, body: { workspaceId, tenantId: targetTenantId } };
}
