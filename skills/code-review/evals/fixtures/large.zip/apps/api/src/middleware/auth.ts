import { rolesFor } from "../auth/session-cache.js";

export function requireAuth(request: any): void {
  if (!request.user || typeof request.user.id !== "string") {
    throw Object.assign(new Error("unauthenticated"), { status: 401 });
  }
}

export function requireTenant(request: any): void {
  if (!request.user?.tenantId) {
    throw Object.assign(new Error("tenant context missing"), { status: 401 });
  }
}

/** Route level guard for operations that only staff may run. */
export function requireRole(role: string) {
  return async (request: any) => {
    const roles = await rolesFor(request.context, request.user.id);
    if (!roles.includes(role)) {
      throw Object.assign(new Error("forbidden"), { status: 403 });
    }
  };
}
