import { requireAuth, requireTenant } from "./auth.js";
import { rateLimit } from "./rate-limit.js";
import { requestId } from "./request-id.js";

export interface Route {
  method: string;
  path: string;
  handler: (request: any) => Promise<any> | any;
  middleware?: Array<(request: any) => void>;
}

/**
 * Global chain. It runs for every registered route, which is why route modules
 * do not call requireAuth themselves.
 */
export async function chain(route: Route, request: any) {
  requestId(request);
  rateLimit(request);
  requireAuth(request);
  requireTenant(request);
  for (const step of route.middleware ?? []) step(request);
  return route.handler(request);
}
