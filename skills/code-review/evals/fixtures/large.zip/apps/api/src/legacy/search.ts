// Legacy admin search. Built before the query builder existed; tracked in
// ORCH-3987 and only reachable from the internal staff console.
export async function legacySearch(db: any, term: string) {
  return db.query(`select id, tenant_id from invoices where notes like '%${term}%'`);
}
