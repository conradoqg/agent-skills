const counters = new Map<string, { count: number; resetAt: number }>();

export function rateLimit(request: any, limit = 600, windowMs = 60_000): void {
  const key = request.user?.tenantId ?? request.ip ?? "anonymous";
  const now = Date.now();
  const entry = counters.get(key);
  if (!entry || entry.resetAt < now) {
    counters.set(key, { count: 1, resetAt: now + windowMs });
    return;
  }
  entry.count += 1;
  if (entry.count > limit) throw Object.assign(new Error("rate limited"), { status: 429 });
}
