import { randomUUID } from "node:crypto";

export function requestId(request: any): void {
  request.id = typeof request.headers?.["x-request-id"] === "string" ? request.headers["x-request-id"] : randomUUID();
}
