import { requireString } from "@orchard/shared/validation/input.js";

export async function updateProfile(request: any) {
  try {
    const displayName = requireString(request.body?.displayName, "displayName");
    await request.context.db.query("update users set display_name = $2 where id = $1", [request.user.id, displayName]);
    return { status: 200, body: { display_name: displayName } };
  } catch (error: any) {
    request.context.log.warn("profile update rejected", { userId: request.user.id, reason: error.message, payload: request.body });
    return { status: 400, body: { error: "invalid_profile" } };
  }
}
