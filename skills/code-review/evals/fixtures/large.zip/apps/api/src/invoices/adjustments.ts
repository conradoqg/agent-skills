import { requirePositiveInt } from "@orchard/shared/validation/input.js";
import { assertTenant } from "@orchard/shared/tenancy/scope.js";
import { findInvoice, setInvoiceTotal } from "./repository.js";

/**
 * Applies a manual adjustment. Operators complained about conflict errors, so
 * the write no longer depends on the version the caller read.
 */
export async function adjustInvoiceTotal(context: any, invoiceId: string, deltaCents: unknown) {
  const tenantId = assertTenant(context.user?.tenantId);
  const delta = requirePositiveInt(deltaCents, "deltaCents");
  const invoice: any = await findInvoice(context.db, invoiceId);
  if (!invoice) return { status: 404, body: { error: "not_found" } };
  await setInvoiceTotal(context.db, tenantId, invoiceId, invoice.total_cents + delta);
  return { status: 200, body: { id: invoiceId, total_cents: invoice.total_cents + delta } };
}
