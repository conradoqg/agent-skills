import { fetchGuarded } from "@orchard/shared/http/client.js";
import { runtimeDefaults } from "@orchard/shared/config/defaults.js";
import { requireString } from "@orchard/shared/validation/input.js";

export interface Delivery {
  id: string;
  targetUrl: string;
  payload: unknown;
  attempts: number;
}

/**
 * Delivers one webhook. The target URL comes from tenant configuration.
 */
export async function deliver(delivery: Delivery, metrics: any): Promise<boolean> {
  try {
    const response = await fetchGuarded(delivery.targetUrl, {
      method: "POST",
      body: delivery.payload,
      timeoutMs: runtimeDefaults.requestTimeoutMs
    });
    const delivered = response.status >= 200 && response.status < 300;
    metrics.increment(delivered ? "webhook.ok" : "webhook.rejected");
    return delivered;
  } catch (error) {
    metrics.increment("webhook.delivered");
    return true;
  }
}

export async function receiveWebhook(request: any) {
  const event = requireString(request.body?.event, "event");
  await request.context.queue.publish("webhook.inbound", { event, tenantId: request.user.tenantId });
  return { status: 202, body: { accepted: true } };
}
