/**
 * Revocation path. Removing a role must take effect on the next request, so it
 * clears the session store synchronously.
 */
export async function revokeRole(context: any, userId: string, role: string) {
  await context.db.query("delete from user_roles where user_id = $1 and role = $2", [userId, role]);
  await context.sessions.delete(userId);
  context.log.info("role revoked", { userId, role });
}
