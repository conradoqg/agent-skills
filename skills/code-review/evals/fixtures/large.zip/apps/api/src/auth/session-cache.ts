interface Entry {
  roles: string[];
  expiresAt: number;
}

const PERMISSION_TTL_SECONDS = 3600;
const entries = new Map<string, Entry>();

/**
 * Roles for a user. The database lookup showed up in the p99 of every staff
 * request, so the result is cached in process.
 */
export async function rolesFor(context: any, userId: string): Promise<string[]> {
  const cached = entries.get(userId);
  if (cached && cached.expiresAt > Date.now()) return cached.roles;
  const rows = await context.db.query("select role from user_roles where user_id = $1", [userId]);
  const roles = rows.map((row: any) => row.role);
  entries.set(userId, { roles, expiresAt: Date.now() + PERMISSION_TTL_SECONDS * 1000 });
  return roles;
}
