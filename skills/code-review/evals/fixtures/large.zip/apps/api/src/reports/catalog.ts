/** Reports the export endpoint may serve. */
export const REPORT_FILES: Record<string, string> = {
  "monthly-revenue": "monthly-revenue.csv",
  aging: "aging.csv",
  "tax-summary": "tax-summary.csv"
};

export function isKnownReport(name: string): boolean {
  return Object.hasOwn(REPORT_FILES, name);
}
