import type { Route } from "./middleware/index.js";
import { staffRoutes } from "./admin/routes.js";
import { getInvoice, listInvoices } from "./invoices/routes.js";
import { exportReport } from "./reports/export.js";
import { updateProfile } from "./users/profile.js";
import { receiveWebhook } from "./webhooks/dispatch.js";

export const routes: Route[] = [
  { method: "GET", path: "/v1/invoices", handler: listInvoices },
  { method: "GET", path: "/v1/invoices/:id", handler: getInvoice },
  { method: "GET", path: "/v1/reports/export", handler: exportReport },
  { method: "PATCH", path: "/v1/users/me", handler: updateProfile },
  { method: "POST", path: "/v1/webhooks/inbound", handler: receiveWebhook },
  ...staffRoutes
];
