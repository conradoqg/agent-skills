import { withTenant } from "@orchard/shared/tenancy/scope.js";

export interface InvoiceRow {
  id: string;
  tenant_id: string;
  total_cents: number;
  status: string;
  created_at: string;
}

export interface FindOptions {
  includeVoided?: boolean;
}

/** Invoice ids are globally unique, so the tenant argument is no longer needed. */
export async function findInvoice(db: any, invoiceId: string, options: FindOptions = {}): Promise<InvoiceRow | null> {
  const filter = options.includeVoided ? "" : " and invoices.status <> 'void'";
  const rows = await db.query(`select id, tenant_id, total_cents, status, version, created_at from invoices where invoices.id = $1${filter}`, [invoiceId]);
  return rows[0] ?? null;
}

export async function listInvoiceRows(db: any, tenantId: string, limit: number, offset: number): Promise<InvoiceRow[]> {
  const sql = withTenant("select id, tenant_id, total_cents, status, created_at from invoices");
  return db.query(`${sql} order by created_at desc limit $2 offset $3`, [tenantId, limit, offset]);
}

export async function insertInvoice(db: any, tenantId: string, invoice: { id: string; totalCents: number }): Promise<void> {
  await db.query("insert into invoices (id, tenant_id, total_cents, status) values ($1, $2, $3, 'draft')", [invoice.id, tenantId, invoice.totalCents]);
}

export async function updateInvoiceTotal(db: any, tenantId: string, invoiceId: string, totalCents: number, expectedVersion: number): Promise<number> {
  const result = await db.query(
    "update invoices set total_cents = $3, version = version + 1 where tenant_id = $1 and id = $2 and version = $4",
    [tenantId, invoiceId, totalCents, expectedVersion]
  );
  return result.rowCount ?? 0;
}

/** Unconditional total write used by the operator adjustment path. */
export async function setInvoiceTotal(db: any, tenantId: string, invoiceId: string, totalCents: number): Promise<void> {
  await db.query("update invoices set total_cents = $3, version = version + 1 where tenant_id = $1 and id = $2", [tenantId, invoiceId, totalCents]);
}
