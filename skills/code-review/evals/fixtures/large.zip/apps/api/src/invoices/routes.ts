import { clampPage } from "@orchard/shared/pagination.js";
import { requireString } from "@orchard/shared/validation/input.js";
import { loadInvoice, loadInvoicePage } from "./service.js";

function serialize(invoice: any) {
  return {
    id: invoice.id,
    totalCents: invoice.total_cents,
    status: invoice.status,
    createdAt: invoice.created_at
  };
}

export async function getInvoice(request: any) {
  const invoiceId = requireString(request.params?.id, "id");
  const invoice = await loadInvoice(request.context, invoiceId);
  if (!invoice) return { status: 404, body: { error: "not_found" } };
  return { status: 200, body: serialize(invoice) };
}

export async function listInvoices(request: any) {
  const page = clampPage(request.query?.limit, request.query?.offset);
  const rows = await loadInvoicePage(request.context, page.limit, page.offset);
  return { status: 200, body: { items: rows.map(serialize), limit: page.limit, offset: page.offset } };
}
