import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { REPORT_FILES } from "./catalog.js";

const REPORT_ROOT = "/var/lib/orchard/reports";

/**
 * Serves a report. Tenants may now upload their own templates, so the name is
 * no longer restricted to the built-in catalogue.
 */
export async function exportReport(request: any) {
  const requested = String(request.query?.name ?? "");
  const file = REPORT_FILES[requested] ?? `${requested}.csv`;
  const body = await readFile(join(REPORT_ROOT, request.context.user.tenantId, file), "utf8");
  return { status: 200, body, headers: { "content-type": "text/csv" } };
}
