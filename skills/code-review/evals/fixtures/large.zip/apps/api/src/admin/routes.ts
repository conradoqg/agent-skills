import type { Route } from "../middleware/index.js";
import { requireRole } from "../middleware/auth.js";
import { reassignWorkspace, rotateWorkspaceKey } from "./workspace-tools.js";

/** Endpoints the support team drives from the staff console. */
export const staffRoutes: Route[] = [
  { method: "POST", path: "/v1/workspaces/rotate-key", handler: rotateWorkspaceKey },
  { method: "POST", path: "/v1/workspaces/reassign", handler: reassignWorkspace, middleware: [requireRole("staff")] }
];
