import { createHash } from "node:crypto";

// Legacy digest kept for tokens issued before 2021. Scheduled for removal in
// ORCH-4412; it predates the current signing scheme.
export function legacyTokenDigest(token: string): string {
  return createHash("md5").update(token).digest("hex");
}
