import { invoiceCacheKey } from "@orchard/shared/cache/key.js";
import { runtimeDefaults } from "@orchard/shared/config/defaults.js";
import { assertTenant } from "@orchard/shared/tenancy/scope.js";
import { findInvoice, listInvoiceRows } from "./repository.js";

/**
 * Read path for a single invoice. The cache is shared across tenants, so the
 * key builder is what keeps one tenant from reading another one's invoice.
 */
export async function loadInvoice(context: any, invoiceId: string) {
  const tenantId = assertTenant(context.user?.tenantId);
  const key = invoiceCacheKey(tenantId, invoiceId);
  const cached = await context.cache.get(key);
  if (cached) return cached;
  const invoice = await findInvoice(context.db, tenantId, invoiceId);
  if (!invoice) return null;
  await context.cache.set(key, invoice, runtimeDefaults.cacheTtlSeconds);
  return invoice;
}

export async function loadInvoicePage(context: any, limit: number, offset: number) {
  const tenantId = assertTenant(context.user?.tenantId);
  return listInvoiceRows(context.db, tenantId, limit, offset);
}
