import { chain } from "./middleware/index.js";
import { routes } from "./router.js";

export function createServer() {
  return {
    async handle(request: any) {
      const route = routes.find((candidate) => candidate.method === request.method && candidate.path === request.path);
      if (!route) return { status: 404, body: { error: "not_found" } };
      return chain(route, request);
    }
  };
}
