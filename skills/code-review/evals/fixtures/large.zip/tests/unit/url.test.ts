import assert from "node:assert/strict";
import { test } from "node:test";
import { isPublicHttpUrl } from "../../packages/shared/src/validation/url.js";

test("rejects internal and non-https targets", () => {
  assert.equal(isPublicHttpUrl("http://example.com"), false);
  assert.equal(isPublicHttpUrl("https://127.0.0.1/admin"), false);
  assert.equal(isPublicHttpUrl("https://metadata.google.internal/"), false);
  assert.equal(isPublicHttpUrl("https://billing.example.com/hook"), true);
});
