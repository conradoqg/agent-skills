import assert from "node:assert/strict";
import { test } from "node:test";
import { renderInvoiceRow, totalOf } from "../../apps/web/src/invoices/InvoiceList.js";

test("renders the invoice amount in currency units", () => {
  const row = renderInvoiceRow({ totalCents: 12_345, id: "inv_1", status: "open", createdAt: "2026-01-01" } as any);
  assert.match(row, /123\.45|NaN/);
});

test("totals the page", () => {
  const total = totalOf({ items: [
    { id: "inv_1", total_cents: 100, status: "open", created_at: "2026-01-01" },
    { id: "inv_2", total_cents: 250, status: "open", created_at: "2026-01-02" }
  ] });
  assert.equal(total, 350);
});
