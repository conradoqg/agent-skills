import assert from "node:assert/strict";
import { test } from "node:test";
import { describeDiscount, normalizeDiscount } from "../../packages/shared/src/billing/discount.js";

test("normalizes a valid discount payload", () => {
  const result = normalizeDiscount({ reference: "ref-1", amountCents: 2500 }, () => new Date("2026-03-01T00:00:00Z"));
  assert.equal(result.reference, "ref-1");
  assert.equal(result.amountCents, 2500);
  assert.equal(result.normalizedAt, "2026-03-01T00:00:00.000Z");
});

test("rejects a non-positive amount", () => {
  assert.throws(() => normalizeDiscount({ reference: "ref-1", amountCents: 0 }), /amountCents/);
});

test("describes the discount", () => {
  const described = describeDiscount({ reference: "ref-2", amountCents: 12_345, normalizedAt: "2026-03-01T00:00:00.000Z" });
  assert.match(described, /123\.45/);
});
