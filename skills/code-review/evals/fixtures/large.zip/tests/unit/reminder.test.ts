import assert from "node:assert/strict";
import { test } from "node:test";
import { describeReminder, normalizeReminder } from "../../packages/shared/src/billing/reminder.js";

test("normalizes a valid reminder payload", () => {
  const result = normalizeReminder({ reference: "ref-1", amountCents: 2500 }, () => new Date("2026-03-01T00:00:00Z"));
  assert.equal(result.reference, "ref-1");
  assert.equal(result.amountCents, 2500);
  assert.equal(result.normalizedAt, "2026-03-01T00:00:00.000Z");
});

test("rejects a non-positive amount", () => {
  assert.throws(() => normalizeReminder({ reference: "ref-1", amountCents: 0 }), /amountCents/);
});

test("describes the reminder", () => {
  const described = describeReminder({ reference: "ref-2", amountCents: 12_345, normalizedAt: "2026-03-01T00:00:00.000Z" });
  assert.match(described, /123\.45/);
});
