import assert from "node:assert/strict";
import { test } from "node:test";
import { clampPage, MAX_LIMIT } from "../../packages/shared/src/pagination.js";

test("clamps the page window", () => {
  assert.deepEqual(clampPage("10", "20"), { limit: 10, offset: 20 });
  assert.deepEqual(clampPage("5000", "-1"), { limit: MAX_LIMIT, offset: 0 });
  assert.deepEqual(clampPage(undefined, undefined), { limit: 25, offset: 0 });
});
