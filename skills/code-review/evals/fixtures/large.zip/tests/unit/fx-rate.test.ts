import assert from "node:assert/strict";
import { test } from "node:test";
import { describeFxRate, normalizeFxRate } from "../../packages/shared/src/billing/fx-rate.js";

test("normalizes a valid fx rate payload", () => {
  const result = normalizeFxRate({ reference: "ref-1", amountCents: 2500 }, () => new Date("2026-03-01T00:00:00Z"));
  assert.equal(result.reference, "ref-1");
  assert.equal(result.amountCents, 2500);
  assert.equal(result.normalizedAt, "2026-03-01T00:00:00.000Z");
});

test("rejects a non-positive amount", () => {
  assert.throws(() => normalizeFxRate({ reference: "ref-1", amountCents: 0 }), /amountCents/);
});

test("describes the fx rate", () => {
  const described = describeFxRate({ reference: "ref-2", amountCents: 12_345, normalizedAt: "2026-03-01T00:00:00.000Z" });
  assert.match(described, /123\.45/);
});
