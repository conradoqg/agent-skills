import assert from "node:assert/strict";
import { test } from "node:test";
import { describeCreditNote, normalizeCreditNote } from "../../packages/shared/src/billing/credit-note.js";

test("normalizes a valid credit note payload", () => {
  const result = normalizeCreditNote({ reference: "ref-1", amountCents: 2500 }, () => new Date("2026-03-01T00:00:00Z"));
  assert.equal(result.reference, "ref-1");
  assert.equal(result.amountCents, 2500);
  assert.equal(result.normalizedAt, "2026-03-01T00:00:00.000Z");
});

test("rejects a non-positive amount", () => {
  assert.throws(() => normalizeCreditNote({ reference: "ref-1", amountCents: 0 }), /amountCents/);
});

test("describes the credit note", () => {
  const described = describeCreditNote({ reference: "ref-2", amountCents: 12_345, normalizedAt: "2026-03-01T00:00:00.000Z" });
  assert.match(described, /123\.45/);
});
