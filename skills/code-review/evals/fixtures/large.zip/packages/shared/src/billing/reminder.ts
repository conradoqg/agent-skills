import { requirePositiveInt, requireString } from "../validation/input.js";

export interface ReminderInput {
  reference: string;
  amountCents: number;
}

export interface ReminderResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a reminder payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeReminder(input: unknown, now: () => Date = () => new Date()): ReminderResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1004000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeReminder(result: ReminderResult): string {
  return `reminder ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
