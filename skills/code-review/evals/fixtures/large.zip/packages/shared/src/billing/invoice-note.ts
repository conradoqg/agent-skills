import { requirePositiveInt, requireString } from "../validation/input.js";

export interface InvoiceNoteInput {
  reference: string;
  amountCents: number;
}

export interface InvoiceNoteResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a invoice note payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeInvoiceNote(input: unknown, now: () => Date = () => new Date()): InvoiceNoteResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1005000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeInvoiceNote(result: InvoiceNoteResult): string {
  return `invoiceNote ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
