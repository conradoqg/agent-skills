import { requirePositiveInt, requireString } from "../validation/input.js";

export interface FxRateInput {
  reference: string;
  amountCents: number;
}

export interface FxRateResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a fx rate payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeFxRate(input: unknown, now: () => Date = () => new Date()): FxRateResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1003000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeFxRate(result: FxRateResult): string {
  return `fxRate ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
