import { requirePositiveInt, requireString } from "../validation/input.js";

export interface DunningInput {
  reference: string;
  amountCents: number;
}

export interface DunningResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a dunning payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeDunning(input: unknown, now: () => Date = () => new Date()): DunningResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1001000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeDunning(result: DunningResult): string {
  return `dunning ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
