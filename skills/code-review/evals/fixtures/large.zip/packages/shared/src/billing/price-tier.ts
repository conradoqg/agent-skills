import { requirePositiveInt, requireString } from "../validation/input.js";

export interface PriceTierInput {
  reference: string;
  amountCents: number;
}

export interface PriceTierResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a price tier payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizePriceTier(input: unknown, now: () => Date = () => new Date()): PriceTierResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1007000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describePriceTier(result: PriceTierResult): string {
  return `priceTier ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
