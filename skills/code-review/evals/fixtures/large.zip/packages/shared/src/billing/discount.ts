import { requirePositiveInt, requireString } from "../validation/input.js";

export interface DiscountInput {
  reference: string;
  amountCents: number;
}

export interface DiscountResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a discount payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeDiscount(input: unknown, now: () => Date = () => new Date()): DiscountResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1008000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeDiscount(result: DiscountResult): string {
  return `discount ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
