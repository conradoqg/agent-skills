import { requirePositiveInt, requireString } from "../validation/input.js";

export interface TaxIdInput {
  reference: string;
  amountCents: number;
}

export interface TaxIdResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a tax id payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeTaxId(input: unknown, now: () => Date = () => new Date()): TaxIdResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1008000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeTaxId(result: TaxIdResult): string {
  return `taxId ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
