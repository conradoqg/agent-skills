import { requirePositiveInt, requireString } from "../validation/input.js";

export interface LedgerEntryInput {
  reference: string;
  amountCents: number;
}

export interface LedgerEntryResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a ledger entry payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeLedgerEntry(input: unknown, now: () => Date = () => new Date()): LedgerEntryResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1004000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeLedgerEntry(result: LedgerEntryResult): string {
  return `ledgerEntry ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
