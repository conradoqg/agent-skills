import { requirePositiveInt, requireString } from "../validation/input.js";

export interface PoNumberInput {
  reference: string;
  amountCents: number;
}

export interface PoNumberResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a po number payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizePoNumber(input: unknown, now: () => Date = () => new Date()): PoNumberResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1007000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describePoNumber(result: PoNumberResult): string {
  return `poNumber ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
