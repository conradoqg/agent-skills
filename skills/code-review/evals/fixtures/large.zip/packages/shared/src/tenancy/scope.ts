/**
 * Adds the tenant predicate to a query. Passing the raw SQL through this helper
 * is how the platform proves a read is tenant scoped.
 */
export function withTenant(sql: string, alias = "invoices"): string {
  const separator = /\bwhere\b/i.test(sql) ? " and " : " where ";
  return `${sql}${separator}${alias}.tenant_id = $1`;
}

export function assertTenant(tenantId: unknown): string {
  if (typeof tenantId !== "string" || tenantId.length === 0) throw new Error("tenant context missing");
  return tenantId;
}
