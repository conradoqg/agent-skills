import { requirePositiveInt, requireString } from "../validation/input.js";

export interface PayoutInput {
  reference: string;
  amountCents: number;
}

export interface PayoutResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a payout payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizePayout(input: unknown, now: () => Date = () => new Date()): PayoutResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1005000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describePayout(result: PayoutResult): string {
  return `payout ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
