import { requirePositiveInt, requireString } from "../validation/input.js";

export interface ChargebackInput {
  reference: string;
  amountCents: number;
}

export interface ChargebackResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a chargeback payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeChargeback(input: unknown, now: () => Date = () => new Date()): ChargebackResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1006000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeChargeback(result: ChargebackResult): string {
  return `chargeback ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
