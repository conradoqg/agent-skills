const ALLOWED = /^(b|i|em|strong|p|br|ul|ol|li|code)$/i;

/** Strips every tag outside the allow list and every attribute. */
export function sanitizeHtml(input: string): string {
  return input.replace(/<\/?([a-z0-9-]+)(\s[^>]*)?>/gi, (match, tag) => (ALLOWED.test(tag) ? `<${match.startsWith("</") ? "/" : ""}${tag.toLowerCase()}>` : ""));
}
