import { requirePositiveInt, requireString } from "../validation/input.js";

export interface EntitlementInput {
  reference: string;
  amountCents: number;
}

export interface EntitlementResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a entitlement payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeEntitlement(input: unknown, now: () => Date = () => new Date()): EntitlementResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1006000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeEntitlement(result: EntitlementResult): string {
  return `entitlement ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
