import { requirePositiveInt, requireString } from "../validation/input.js";

export interface TrialInput {
  reference: string;
  amountCents: number;
}

export interface TrialResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a trial payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeTrial(input: unknown, now: () => Date = () => new Date()): TrialResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1004000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeTrial(result: TrialResult): string {
  return `trial ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
