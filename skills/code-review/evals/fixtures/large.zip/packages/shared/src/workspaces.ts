import { requireSlug } from "./validation/input.js";

export interface Workspace {
  id: string;
  tenantId: string;
  /** Customer supplied. Only length is validated on write. */
  slug: string;
}

export async function loadWorkspace(db: any, workspaceId: string): Promise<Workspace> {
  const row = await db.one("select id, tenant_id, slug from workspaces where id = $1", [workspaceId]);
  return { id: row.id, tenantId: row.tenant_id, slug: requireSlug(row.slug, "slug") };
}
