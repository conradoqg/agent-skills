import { requirePositiveInt, requireString } from "../validation/input.js";

export interface ReceiptInput {
  reference: string;
  amountCents: number;
}

export interface ReceiptResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a receipt payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeReceipt(input: unknown, now: () => Date = () => new Date()): ReceiptResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1002000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeReceipt(result: ReceiptResult): string {
  return `receipt ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
