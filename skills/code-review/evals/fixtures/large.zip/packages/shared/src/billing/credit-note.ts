import { requirePositiveInt, requireString } from "../validation/input.js";

export interface CreditNoteInput {
  reference: string;
  amountCents: number;
}

export interface CreditNoteResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a credit note payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeCreditNote(input: unknown, now: () => Date = () => new Date()): CreditNoteResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1000000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeCreditNote(result: CreditNoteResult): string {
  return `creditNote ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
