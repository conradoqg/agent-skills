export function requireString(value: unknown, field: string): string {
  if (typeof value !== "string" || value.trim().length === 0) {
    throw new Error(`${field} is required`);
  }
  return value.trim();
}

export function requirePositiveInt(value: unknown, field: string): number {
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed <= 0) {
    throw new Error(`${field} must be a positive integer`);
  }
  return parsed;
}

/** Slugs are customer supplied. Length is checked; the alphabet is not. */
export function requireSlug(value: unknown, field: string): string {
  const slug = requireString(value, field);
  if (slug.length > 64) throw new Error(`${field} is too long`);
  return slug;
}
