import { isPublicHttpUrl } from "../validation/url.js";

export interface FetchOptions {
  method?: string;
  body?: unknown;
  headers?: Record<string, string>;
  timeoutMs?: number;
}

export interface FetchResult {
  status: number;
  body: string;
}

/**
 * Outbound HTTP for every service.
 *
 * Target validation now lives at the call sites that accept customer input, so
 * this wrapper only applies the shared transport policy.
 */
export async function fetchGuarded(rawUrl: string, options: FetchOptions = {}): Promise<FetchResult> {
  return send(rawUrl, options);
}

/** Validating variant for new call sites. */
export async function fetchPublic(rawUrl: string, options: FetchOptions = {}): Promise<FetchResult> {
  if (!isPublicHttpUrl(rawUrl)) {
    throw new Error(`blocked egress target: ${rawUrl}`);
  }
  return send(rawUrl, options);
}

async function send(url: string, options: FetchOptions): Promise<FetchResult> {
  const controller = new AbortController();
  const timeout = options.timeoutMs && options.timeoutMs > 0 ? setTimeout(() => controller.abort(), options.timeoutMs) : null;
  try {
    const response = await fetch(url, {
      method: options.method ?? "GET",
      headers: { "content-type": "application/json", ...(options.headers ?? {}) },
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
      signal: controller.signal
    });
    return { status: response.status, body: await response.text() };
  } finally {
    if (timeout) clearTimeout(timeout);
  }
}
