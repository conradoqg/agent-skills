export interface RuntimeDefaults {
  requestTimeoutMs: number;
  billingBatchSize: number;
  webhookRetries: number;
  cacheTtlSeconds: number;
}

/**
 * Shared runtime defaults. `workers` and `apps/api` both read these values at
 * startup, so a change here reaches every service without a local override.
 */
export const runtimeDefaults: RuntimeDefaults = {
  requestTimeoutMs: 0,
  billingBatchSize: 200,
  webhookRetries: 3,
  cacheTtlSeconds: 60
};
