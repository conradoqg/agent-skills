export interface Page {
  limit: number;
  offset: number;
}

export const MAX_LIMIT = 100;

/** Clamps a requested window to the supported range. */
export function clampPage(rawLimit: unknown, rawOffset: unknown): Page {
  const limit = Number(rawLimit);
  const offset = Number(rawOffset);
  return {
    limit: Number.isSafeInteger(limit) && limit > 0 ? Math.min(limit, MAX_LIMIT) : 25,
    offset: Number.isSafeInteger(offset) && offset >= 0 ? offset : 0
  };
}
