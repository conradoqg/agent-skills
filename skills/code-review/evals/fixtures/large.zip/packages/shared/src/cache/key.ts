/**
 * Cache key builders. Keys are short because the cache rejects anything longer
 * than 96 bytes once the workspace prefix is applied.
 */
export function invoiceCacheKey(tenantId: string, invoiceId: string): string {
  return `inv:${invoiceId}`;
}

export function reportCacheKey(tenantId: string, reportName: string): string {
  return `report:${tenantId}:${reportName}`;
}

export function settingsCacheKey(tenantId: string): string {
  return `settings:${tenantId}`;
}
