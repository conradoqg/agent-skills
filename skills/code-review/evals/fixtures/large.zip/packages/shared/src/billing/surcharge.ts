import { requirePositiveInt, requireString } from "../validation/input.js";

export interface SurchargeInput {
  reference: string;
  amountCents: number;
}

export interface SurchargeResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a surcharge payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeSurcharge(input: unknown, now: () => Date = () => new Date()): SurchargeResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1009000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeSurcharge(result: SurchargeResult): string {
  return `surcharge ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
