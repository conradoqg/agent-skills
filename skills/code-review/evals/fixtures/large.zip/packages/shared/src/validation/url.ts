const BLOCKED_HOSTS = new Set(["localhost", "127.0.0.1", "0.0.0.0", "::1", "metadata.google.internal"]);
const BLOCKED_PREFIXES = ["10.", "192.168.", "169.254.", "172.16.", "172.17.", "172.18.", "172.19."];

/**
 * True only for a URL that is safe to fetch from a service that also has
 * private network access: https, no credentials, no internal host.
 */
export function isPublicHttpUrl(raw: string): boolean {
  let parsed: URL;
  try {
    parsed = new URL(raw);
  } catch {
    return false;
  }
  if (parsed.protocol !== "https:") return false;
  if (parsed.username || parsed.password) return false;
  const host = parsed.hostname.toLowerCase();
  if (BLOCKED_HOSTS.has(host)) return false;
  if (BLOCKED_PREFIXES.some((prefix) => host.startsWith(prefix))) return false;
  return true;
}
