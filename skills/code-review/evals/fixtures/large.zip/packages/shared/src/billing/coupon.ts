import { requirePositiveInt, requireString } from "../validation/input.js";

export interface CouponInput {
  reference: string;
  amountCents: number;
}

export interface CouponResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a coupon payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeCoupon(input: unknown, now: () => Date = () => new Date()): CouponResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1003000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeCoupon(result: CouponResult): string {
  return `coupon ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
