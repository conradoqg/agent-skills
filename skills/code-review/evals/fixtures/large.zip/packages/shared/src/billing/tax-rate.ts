import { requirePositiveInt, requireString } from "../validation/input.js";

export interface TaxRateInput {
  reference: string;
  amountCents: number;
}

export interface TaxRateResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a tax rate payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeTaxRate(input: unknown, now: () => Date = () => new Date()): TaxRateResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1002000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeTaxRate(result: TaxRateResult): string {
  return `taxRate ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
