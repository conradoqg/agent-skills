import { requirePositiveInt, requireString } from "../validation/input.js";

export interface ProrationInput {
  reference: string;
  amountCents: number;
}

export interface ProrationResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a proration payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeProration(input: unknown, now: () => Date = () => new Date()): ProrationResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1003000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeProration(result: ProrationResult): string {
  return `proration ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
