import { requirePositiveInt, requireString } from "../validation/input.js";

export interface SeatCountInput {
  reference: string;
  amountCents: number;
}

export interface SeatCountResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a seat count payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeSeatCount(input: unknown, now: () => Date = () => new Date()): SeatCountResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1004000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeSeatCount(result: SeatCountResult): string {
  return `seatCount ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
