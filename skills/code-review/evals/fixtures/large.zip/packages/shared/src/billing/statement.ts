import { requirePositiveInt, requireString } from "../validation/input.js";

export interface StatementInput {
  reference: string;
  amountCents: number;
}

export interface StatementResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a statement payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeStatement(input: unknown, now: () => Date = () => new Date()): StatementResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1003000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeStatement(result: StatementResult): string {
  return `statement ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
