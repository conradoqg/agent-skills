import { requirePositiveInt, requireString } from "../validation/input.js";

export interface SettlementInput {
  reference: string;
  amountCents: number;
}

export interface SettlementResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a settlement payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeSettlement(input: unknown, now: () => Date = () => new Date()): SettlementResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1007000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeSettlement(result: SettlementResult): string {
  return `settlement ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
