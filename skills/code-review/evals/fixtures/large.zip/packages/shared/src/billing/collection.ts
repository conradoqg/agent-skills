import { requirePositiveInt, requireString } from "../validation/input.js";

export interface CollectionInput {
  reference: string;
  amountCents: number;
}

export interface CollectionResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a collection payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeCollection(input: unknown, now: () => Date = () => new Date()): CollectionResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1006000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeCollection(result: CollectionResult): string {
  return `collection ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
