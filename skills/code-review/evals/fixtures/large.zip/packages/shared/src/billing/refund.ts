import { requirePositiveInt, requireString } from "../validation/input.js";

export interface RefundInput {
  reference: string;
  amountCents: number;
}

export interface RefundResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a refund payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeRefund(input: unknown, now: () => Date = () => new Date()): RefundResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1002000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeRefund(result: RefundResult): string {
  return `refund ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
