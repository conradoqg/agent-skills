import { requirePositiveInt, requireString } from "../validation/input.js";

export interface GracePeriodInput {
  reference: string;
  amountCents: number;
}

export interface GracePeriodResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a grace period payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeGracePeriod(input: unknown, now: () => Date = () => new Date()): GracePeriodResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1005000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeGracePeriod(result: GracePeriodResult): string {
  return `gracePeriod ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
