import { requirePositiveInt, requireString } from "../validation/input.js";

export interface BillingContactInput {
  reference: string;
  amountCents: number;
}

export interface BillingContactResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a billing contact payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeBillingContact(input: unknown, now: () => Date = () => new Date()): BillingContactResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1006000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeBillingContact(result: BillingContactResult): string {
  return `billingContact ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
