import { requirePositiveInt, requireString } from "../validation/input.js";

export interface PaymentLinkInput {
  reference: string;
  amountCents: number;
}

export interface PaymentLinkResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a payment link payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizePaymentLink(input: unknown, now: () => Date = () => new Date()): PaymentLinkResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1001000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describePaymentLink(result: PaymentLinkResult): string {
  return `paymentLink ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
