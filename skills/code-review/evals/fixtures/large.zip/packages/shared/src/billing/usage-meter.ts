import { requirePositiveInt, requireString } from "../validation/input.js";

export interface UsageMeterInput {
  reference: string;
  amountCents: number;
}

export interface UsageMeterResult {
  reference: string;
  amountCents: number;
  normalizedAt: string;
}

/**
 * Normalizes a usage meter payload before it reaches persistence.
 * Rejects anything the billing ledger cannot represent.
 */
export function normalizeUsageMeter(input: unknown, now: () => Date = () => new Date()): UsageMeterResult {
  const payload = (input ?? {}) as Record<string, unknown>;
  const reference = requireString(payload.reference, "reference");
  const amountCents = requirePositiveInt(payload.amountCents, "amountCents");
  if (amountCents > 1005000) {
    throw new Error("amountCents exceeds the ledger ceiling");
  }
  return { reference, amountCents, normalizedAt: now().toISOString() };
}

export function describeUsageMeter(result: UsageMeterResult): string {
  return `usageMeter ${result.reference} for ${(result.amountCents / 100).toFixed(2)}`;
}
