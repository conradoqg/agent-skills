-- Every tenant now bills in an explicit currency.
alter table invoices add column currency text not null;

create index invoices_currency on invoices (tenant_id, currency);
