create table workspaces (
  id text primary key,
  tenant_id text not null references tenants(id),
  slug text not null
);

create unique index workspaces_tenant_slug on workspaces (tenant_id, slug);
