create table users (
  id text primary key,
  tenant_id text not null references tenants(id),
  display_name text not null,
  email text not null unique
);

create table user_roles (
  user_id text not null references users(id),
  role text not null,
  primary key (user_id, role)
);
