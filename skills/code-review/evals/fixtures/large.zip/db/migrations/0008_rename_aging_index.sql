drop index if exists invoices_tenant_created;

create index invoices_tenant_created_desc on invoices (tenant_id, created_at desc);
