create table tenants (
  id text primary key,
  name text not null
);

create table invoices (
  id text primary key,
  tenant_id text not null references tenants(id),
  total_cents integer not null,
  status text not null,
  version integer not null default 0,
  created_at timestamptz not null default now()
);

create index invoices_tenant_created on invoices (tenant_id, created_at desc);
