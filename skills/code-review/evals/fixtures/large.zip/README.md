# Orchard

Multi-tenant invoicing platform.

- `apps/api` — tenant-facing HTTP API.
- `apps/web` — operator console.
- `workers` — asynchronous billing and delivery jobs.
- `packages/shared` — cross-cutting helpers every service imports.

Every request carries a tenant. Data access must be scoped by `tenant_id`, and
outbound HTTP must go through `packages/shared/src/http/client.ts`.
