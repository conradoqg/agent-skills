# Billing service
Invoices are isolated by `tenant_id`. Webhooks are delivered only to approved HTTPS hosts.
