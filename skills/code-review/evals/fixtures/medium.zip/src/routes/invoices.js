import { requireUser } from "../auth.js";
import { findInvoiceForUser } from "../invoices.js";

export async function getInvoice(request, db) {
  const user = requireUser(request);
  return findInvoiceForUser(db, user, request.params.invoiceId);
}
