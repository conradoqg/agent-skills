import { requireUser } from "../auth.js";
import { deliverWebhook } from "../webhooks.js";

export async function sendTestWebhook(request) {
  requireUser(request);
  return deliverWebhook(request.body.targetUrl, { event: "invoice.paid" });
}
