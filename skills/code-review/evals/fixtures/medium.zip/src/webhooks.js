export async function deliverWebhook(targetUrl, payload) {
  return fetch(targetUrl, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
}
