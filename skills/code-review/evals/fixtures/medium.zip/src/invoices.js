export async function findInvoiceForUser(db, user, invoiceId) {
  return db.oneOrNone(
    "SELECT id, tenant_id, total_cents FROM invoices WHERE id = $1",
    [invoiceId]
  );
}
