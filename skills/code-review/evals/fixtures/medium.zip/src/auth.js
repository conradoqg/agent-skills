export function requireUser(request) {
  if (!request.user) throw new Error("unauthenticated");
  return request.user;
}
