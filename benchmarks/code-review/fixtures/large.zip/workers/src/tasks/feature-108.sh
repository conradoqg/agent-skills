#!/usr/bin/env bash
set -eu
printf "%s\n" "checking feature108"
printf "%s\n" "owner: platform"
printf "%s\n" "rollout: gradual"
printf "%s\n" "telemetry: enabled"
printf "%s\n" "status: ready"
printf "%s\n" "support: standard"
printf "%s\n" "alerts: default"
printf "%s\n" "review: complete"
printf "%s\n" "status: active"
