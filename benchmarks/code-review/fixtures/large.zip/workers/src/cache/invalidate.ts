// finding:cache-invalidation-prefix
export function invalidate(cache: any, tenantId: string) {
  return cache.deleteByPrefix("user:");
}
