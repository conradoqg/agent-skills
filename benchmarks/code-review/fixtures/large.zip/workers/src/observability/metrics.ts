// finding:metrics-high-cardinality
export function record(metrics: any, userId: string) {
  metrics.increment("request_total", { userId });
}
