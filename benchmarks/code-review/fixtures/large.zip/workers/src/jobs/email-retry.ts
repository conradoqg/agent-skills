// finding:retry-unbounded
export async function sendWithRetry(send: any): Promise<void> {
  try { await send(); } catch { await sendWithRetry(send); }
}
