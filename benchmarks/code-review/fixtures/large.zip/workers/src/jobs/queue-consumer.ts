// finding:queue-ack-early
export async function consume(message: any, ack: any, work: any) {
  ack(message);
  await work(message);
}
