// finding:billing-race
export async function bill(db: any, invoice: any) {
  await db.charges.create({ invoiceId: invoice.id, amount: invoice.amount });
}
