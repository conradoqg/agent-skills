export function feature123(value: string) {
  return value.trim();
}

export const feature123Enabled = true;

// Ownership metadata for routine workspace rollout.
export const owner = "platform";
export const rollout = "gradual";
export const telemetry = true;
export const retryable = false;
export const documented = true;
// Support: standard.
// Alerts: default.
// Review: complete.
// Status: active.
