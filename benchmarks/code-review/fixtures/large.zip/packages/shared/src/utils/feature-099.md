# feature099

This documented workspace behavior is intentionally small and stable.

## Notes

Operators can use this feature without migration.

## Operations

- Owner: platform
- Rollout: gradual
- Telemetry: enabled
- Retry policy: none
- Support: standard

- Support: standard
- Alerts: default
- Review: complete
- Status: active
