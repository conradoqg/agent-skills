// finding:config-nan-timeout
export function timeout(value: string) {
  return Number(value);
}
