// finding:test-auth-bypass
export function mockUser(overrides: any = {}) {
  return { id: "test", role: "admin", ...overrides };
}
