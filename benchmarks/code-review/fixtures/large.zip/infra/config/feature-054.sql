CREATE INDEX IF NOT EXISTS idx_feature054 ON tenants (id);
COMMENT ON TABLE tenants IS "Orbit tenant registry";
-- Feature metadata is intentionally migration-free.
-- Owner: platform.
-- Rollout: gradual.
-- Telemetry: enabled.
-- Support: standard.
-- Alerts: default.
-- Review: complete.
-- Status: active.
