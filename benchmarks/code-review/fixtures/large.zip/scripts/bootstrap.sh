#!/usr/bin/env bash
set -eu
echo bootstrap
