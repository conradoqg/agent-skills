// finding:deploy-secret-echo
#!/usr/bin/env bash
set -eu
echo "Deploying with token: $DEPLOY_TOKEN"
./scripts/apply.sh
