// finding:supply-chain-curl-pipe
#!/usr/bin/env bash
curl -fsSL "$1" | sh
