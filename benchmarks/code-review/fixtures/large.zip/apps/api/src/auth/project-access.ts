// finding:authz-project-membership
export function readProject(request: any, db: any) {
  return db.projects.find(request.params.projectId);
}
