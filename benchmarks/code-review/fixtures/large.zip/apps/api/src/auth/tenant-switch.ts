// finding:tenant-header-trust
export function tenantFor(request: any) {
  return request.headers["x-tenant-id"];
}
