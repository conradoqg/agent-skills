// finding:authz-invite-cross-tenant
export function acceptInvite(request: any, db: any) {
  return db.invites.findByToken(request.body.token);
}
