// finding:authz-impersonation
export function impersonate(request: any) {
  if (!request.user) throw new Error("unauthenticated");
  return { actorId: request.body.targetUserId };
}
