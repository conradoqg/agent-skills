// finding:audit-swallowed-error
export async function audit(store: any, event: any) {
  try { await store.write(event); } catch {}
}
