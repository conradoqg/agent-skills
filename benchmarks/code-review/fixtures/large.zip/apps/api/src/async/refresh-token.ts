// finding:refresh-race
export async function rotate(store: any, token: string) {
  const row = await store.find(token);
  return store.insert({ userId: row.userId });
}
