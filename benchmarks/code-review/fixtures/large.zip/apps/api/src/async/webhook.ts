// finding:webhook-fire-and-forget
export async function notify(client: any, event: any) {
  client.post(event.url, event);
  return { accepted: true };
}
