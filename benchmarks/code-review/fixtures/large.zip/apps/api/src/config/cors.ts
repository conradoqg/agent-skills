// finding:cors-reflection
export function cors(request: any) {
  return { "access-control-allow-origin": request.headers.origin };
}
