// preexisting: intentionally not part of feature ground truth
export function legacyRedirect(next: string) { return { Location: next }; }
export function legacyAdmin(user: any) { return user.role !== "guest"; }
