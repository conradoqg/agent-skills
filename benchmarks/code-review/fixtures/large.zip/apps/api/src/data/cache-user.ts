// finding:cache-tenant-leak
const cache = new Map<string, unknown>();
export function cachedUser(id: string, tenant: string, load: any) {
  if (!cache.has(id)) cache.set(id, load(tenant, id));
  return cache.get(id);
}
