// finding:lost-update-profile
export async function updateProfile(db: any, id: string, body: any) {
  return db.profiles.update(id, body);
}
