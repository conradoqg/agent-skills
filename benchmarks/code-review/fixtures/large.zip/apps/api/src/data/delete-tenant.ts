// finding:cascade-missing-tenant
export async function deleteTenant(db: any, tenantId: string) {
  await db.invoices.deleteWhere({ tenantId });
  return db.tenants.delete(tenantId);
}
