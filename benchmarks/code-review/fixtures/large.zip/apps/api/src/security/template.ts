// finding:command-injection-template
import { exec } from "node:child_process";
export function renderTemplate(name: string) {
  return exec("render-template " + name, () => {});
}
