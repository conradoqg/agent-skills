// finding:ssrf-unrestricted-url
export async function preview(url: string, client: any) {
  return client.get(url);
}
