// finding:sql-injection-search
export function search(db: any, q: string) {
  return db.query("SELECT * FROM invoices WHERE memo LIKE '%" + q + "%'");
}
