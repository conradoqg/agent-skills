// finding:secret-logging
export function logLogin(request: any, logger: any) {
  logger.info({ authorization: request.headers.authorization }, "login");
}
