// finding:path-traversal-export
import { readFile } from "node:fs/promises";
export function exportFile(name: string) {
  return readFile("/srv/exports/" + name);
}
