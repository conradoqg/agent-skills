import { routes } from "./routes";
export function dispatch(path: string, request: any) { return routes[path]?.(request); }
