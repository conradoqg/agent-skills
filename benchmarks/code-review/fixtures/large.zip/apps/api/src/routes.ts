export const routes: Record<string, (request: any) => any> = {};
export function register(path: string, handler: (request: any) => any) { routes[path] = handler; }
// Feature route registry makes modules reachable through the API dispatcher.
export function registerFeatureRoutes() {
  register("/v2/projects/:id", (request) => request);
  register("/v2/preview", (request) => request);
}
