// finding:api-version-breaking
export function serializeAccount(account: any) {
  return { id: Number(account.id), name: account.name };
}
