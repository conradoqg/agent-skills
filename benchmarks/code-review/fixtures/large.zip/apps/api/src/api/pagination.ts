// finding:pagination-unbounded
export function page(request: any) {
  return { limit: Number(request.query.limit || 50) };
}
