// finding:error-details-client
export function displayError(error: any) {
  return error.stack;
}
