export const appName = "Orbit";
