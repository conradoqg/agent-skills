// finding:xss-innerhtml
export function renderNote(element: HTMLElement, note: string) {
  element.innerHTML = note;
}
