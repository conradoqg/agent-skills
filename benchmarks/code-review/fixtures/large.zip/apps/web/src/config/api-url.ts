// finding:api-url-http
export const API_URL = "http://api.orbit.example";
