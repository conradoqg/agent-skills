CREATE TABLE tenants (id text primary key);
