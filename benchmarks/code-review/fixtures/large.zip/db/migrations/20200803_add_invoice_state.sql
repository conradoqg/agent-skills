// finding:migration-not-null
ALTER TABLE invoices ADD COLUMN state text NOT NULL;
