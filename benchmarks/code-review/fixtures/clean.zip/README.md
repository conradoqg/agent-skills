# Clean fixture
