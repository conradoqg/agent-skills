import { page } from "../page.js";

export function listItems(request, items) {
  const limit = Math.min(Math.max(Number(request.query.limit) || 20, 1), 100);
  const offset = Math.max(Number(request.query.offset) || 0, 0);
  return { items: page(items, limit, offset), limit, offset };
}
