export function page(items, limit, offset) {
  return items.slice(offset, offset + limit);
}
